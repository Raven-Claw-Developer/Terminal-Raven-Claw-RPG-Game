time_1=0.5
time_2=1

if ! command -v tilix &> /dev/null
then
    echo "Installing Packages ..."
    sudo apt update
    sudo apt upgrade
    sudo apt install -y tilix
    sudo apt install -y xdotool
    sudo apt install -y whiptail
    sudo apt install -y dialog
    sudo apt install -y jq
fi

layout_path="$HOME/RPG Game/Linux/Tilix Layouts/Default.json"
tilix --session "$layout_path" &
sleep $time_1

player_stats_script="$HOME/RPG Game/Linux/Template/Terminals/Player Data/Player_Info.sh"
chmod +x "$player_stats_script"
sleep $time_1

mouse_path="$HOME/RPG Game/Linux/Tilix Layouts/Mouse_Pos_Default.json"

# Row 1
mouse_x_set=$(jq -r '.Row_1.Settings["X"]' "$mouse_path")
mouse_y_set=$(jq -r '.Row_1.Settings["Y"]' "$mouse_path")
mouse_x_inv=$(jq -r '.Row_1.Inventory["X"]' "$mouse_path")
mouse_y_inv=$(jq -r '.Row_1.Inventory["Y"]' "$mouse_path")
mouse_x_shop=$(jq -r '.Row_1.Shop["X"]' "$mouse_path")
mouse_y_shop=$(jq -r '.Row_1.Shop["Y"]' "$mouse_path")
mouse_x_npcs=$(jq -r '.Row_1.Npcs["X"]' "$mouse_path")
mouse_y_npcs=$(jq -r '.Row_1.Npcs["Y"]' "$mouse_path")
mouse_x_skt=$(jq -r '.Row_1.Skill_Tree["X"]' "$mouse_path")
mouse_y_skt=$(jq -r '.Row_1.Skill_Tree["Y"]' "$mouse_path")
# Row 2
mouse_x_plst=$(jq -r '.Row_2.Player_Stats["X"]' "$mouse_path")
mouse_y_plst=$(jq -r '.Row_2.Player_Stats["Y"]' "$mouse_path")
mouse_x_mst=$(jq -r '.Row_2.Main_Story["X"]' "$mouse_path")
mouse_y_mst=$(jq -r '.Row_2.Main_Story["Y"]' "$mouse_path")
mouse_x_map=$(jq -r '.Row_2.Map["X"]' "$mouse_path")
mouse_y_map=$(jq -r '.Row_2.Map["Y"]' "$mouse_path")
mouse_x_fsttr=$(jq -r '.Row_2.Fast_Travel["X"]' "$mouse_path")
mouse_y_fsttr=$(jq -r '.Row_2.Fast_Travel["Y"]' "$mouse_path")


#xdotool mousemove $mouse_x_plst $mouse_y_plst click 1

# Playerstats
if [ -n "Player Stats" ]; then
    xdotool windowactive --sync "Player Stats"
    xdotool windowfocus "Player Stats"
    sleep $time_1
    xdotool type --delay 100 "bash '$player_stats_script'"
    sleep $time_1
    xdotool key Return
fi

sleep $time_2

# Inventory
#if [ -n "Inventory" ]; then
#    xdotool windowactivate --sync "$window_id_2"
#    xdotool windowfocus "$window_id_2"
#    sleep $time_1
#    xdotool type --delay 100 "hi"
#    sleep $time_1
#    xdotool key Return
#fi





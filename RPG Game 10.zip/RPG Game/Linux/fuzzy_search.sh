#!/bin/bash

# Eine Liste von Items für die Fuzzy-Suche
items=("Schwert" "Schild" "Bogen" "Trank" "Rüstung" "Magierstab" "Dolch" "Axt" "Pfeil")

# Fuzzy-Suche mit fzf
selected_item=$(printf "%s\n" "${items[@]}" | fzf --prompt="Search: ")


# Wenn ein Item ausgewählt wurde, wird es in einer Dialogbox angezeigt
if [ -n "$selected_item" ]; then
    dialog --msgbox "Du hast das Item '$selected_item' ausgewählt." 8 40

    # favs hinzufügen
    # armpor kits erstellen:
    # etc ...
else
    dialog --msgbox "Keine Auswahl getroffen." 8 40
fi

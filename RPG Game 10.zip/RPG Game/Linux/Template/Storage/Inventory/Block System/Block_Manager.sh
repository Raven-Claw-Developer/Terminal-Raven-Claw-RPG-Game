
mkfifo /tmp/pipe_in_01
mkfifo /tmp/pipe_in_02
mkfifo /tmp/pipe_in_03
mkfifo /tmp/pipe_in_04
mkfifo /tmp/pipe_in_05
mkfifo /tmp/pipe_in_06
mkfifo /tmp/pipe_in_07
mkfifo /tmp/pipe_in_08
mkfifo /tmp/pipe_in_09
mkfifo /tmp/pipe_in_10
mkfifo /tmp/pipe_in_11
mkfifo /tmp/pipe_in_12
mkfifo /tmp/pipe_in_13
mkfifo /tmp/pipe_in_14
mkfifo /tmp/pipe_in_15
mkfifo /tmp/pipe_in_16
mkfifo /tmp/pipe_in_17
mkfifo /tmp/pipe_in_18
mkfifo /tmp/pipe_in_19
mkfifo /tmp/pipe_in_20

mkfifo /tmp/pipe_out_01
mkfifo /tmp/pipe_out_02
mkfifo /tmp/pipe_out_03
mkfifo /tmp/pipe_out_04
mkfifo /tmp/pipe_out_05
mkfifo /tmp/pipe_out_06
mkfifo /tmp/pipe_out_07
mkfifo /tmp/pipe_out_08
mkfifo /tmp/pipe_out_09
mkfifo /tmp/pipe_out_10
mkfifo /tmp/pipe_out_11
mkfifo /tmp/pipe_out_12
mkfifo /tmp/pipe_out_13
mkfifo /tmp/pipe_out_14
mkfifo /tmp/pipe_out_15
mkfifo /tmp/pipe_out_16
mkfifo /tmp/pipe_out_17
mkfifo /tmp/pipe_out_18
mkfifo /tmp/pipe_out_19
mkfifo /tmp/pipe_out_20


pipe_in_01="/tmp/pipe_in_01"
pipe_in_02="/tmp/pipe_in_02"
pipe_in_03="/tmp/pipe_in_03"
pipe_in_04="/tmp/pipe_in_04"
pipe_in_05="/tmp/pipe_in_05"
pipe_in_06="/tmp/pipe_in_06"
pipe_in_07="/tmp/pipe_in_07"
pipe_in_08="/tmp/pipe_in_08"
pipe_in_09="/tmp/pipe_in_09"
pipe_in_10="/tmp/pipe_in_10"
pipe_in_11="/tmp/pipe_in_11"
pipe_in_12="/tmp/pipe_in_12"
pipe_in_13="/tmp/pipe_in_13"
pipe_in_14="/tmp/pipe_in_14"
pipe_in_15="/tmp/pipe_in_15"
pipe_in_16="/tmp/pipe_in_16"
pipe_in_17="/tmp/pipe_in_17"
pipe_in_18="/tmp/pipe_in_18"
pipe_in_19="/tmp/pipe_in_19"
pipe_in_20="/tmp/pipe_in_20"

pipe_out_01="/tmp/pipe_out_01"
pipe_out_02="/tmp/pipe_out_02"
pipe_out_03="/tmp/pipe_out_03"
pipe_out_04="/tmp/pipe_out_04"
pipe_out_05="/tmp/pipe_out_05"
pipe_out_06="/tmp/pipe_out_06"
pipe_out_07="/tmp/pipe_out_07"
pipe_out_08="/tmp/pipe_out_08"
pipe_out_09="/tmp/pipe_out_09"
pipe_out_10="/tmp/pipe_out_10"
pipe_out_11="/tmp/pipe_out_11"
pipe_out_12="/tmp/pipe_out_12"
pipe_out_13="/tmp/pipe_out_13"
pipe_out_14="/tmp/pipe_out_14"
pipe_out_15="/tmp/pipe_out_15"
pipe_out_16="/tmp/pipe_out_16"
pipe_out_17="/tmp/pipe_out_17"
pipe_out_18="/tmp/pipe_out_18"
pipe_out_19="/tmp/pipe_out_19"
pipe_out_20="/tmp/pipe_out_20"

pipe_in_list_1=("$pipe_in_01" "$pipe_in_02" "$pipe_in_03" "$pipe_in_04" "$pipe_in_05")
pipe_in_list_2=("$pipe_in_06" "$pipe_in_17" "$pipe_in_08" "$pipe_in_09" "$pipe_in_10")
pipe_in_list_3=("$pipe_in_11" "$pipe_in_12" "$pipe_in_13" "$pipe_in_14" "$pipe_in_15")
pipe_in_list_4=("$pipe_in_16" "$pipe_in_17" "$pipe_in_18" "$pipe_in_19" "$pipe_in_20")

pipe_out_list_1=("$pipe_out_01" "$pipe_out_02" "$pipe_out_03" "$pipe_out_04" "$pipe_out_05")
pipe_out_list_2=("$pipe_out_06" "$pipe_out_07" "$pipe_out_08" "$pipe_out_09" "$pipe_out_10")
pipe_out_list_3=("$pipe_out_11" "$pipe_out_12" "$pipe_out_13" "$pipe_out_14" "$pipe_out_15")
pipe_out_list_4=("$pipe_out_16" "$pipe_out_17" "$pipe_out_18" "$pipe_out_19" "$pipe_out_20")

pipe_in_list=("${pipe_in_list_1[@]}" "${pipe_in_list_2[@]}" "${pipe_in_list_3[@]}" "${pipe_in_list_4[@]}")
pipe_out_list=("${pipe_out_list_1[@]}" "${pipe_out_list_2[@]}" "${pipe_out_list_3[@]}" "${pipe_out_list_4[@]}")

cd "$HOME/RPG Game/Linux/Template/Storage/Invenory/Blocksystem"
chmod +x Pipe_Creation.ksh
./Pipe_Creation

function controll() {

}

# ===============================================
    # Material // Cell 1_2  




}





function read_pipes() {
    local list_input=("$@")

    for entry in "${list_input[@]}"; do
        if read -r $pipe_in<"$entry"; then
            return $pipe_in
        fi
        sleep 0.55
    done
}

function write_pipes() {
    local list_output=("$@")
    local value=$2

    for entry in "${list_output[@]}"; do
        echo "$value" > $entry 
        sleep 0.67
    done
}

while true; do
    sleep 0.5

    input=$(read_pipes "${pipe_in_list[@]}")
    write_pipes "${pipe_out_list[@]}" "$value"





done




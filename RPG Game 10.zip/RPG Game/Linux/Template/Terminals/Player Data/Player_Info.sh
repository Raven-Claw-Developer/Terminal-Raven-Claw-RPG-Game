#!/bin/bash

# Funktion, um den rechten Teil des Bildschirms zu aktualisieren
show_info() {

    path_pd="$HOME/RPG Game/Linux/Template/Storage/Player/Data/Player_Data.json"
    path_pa="$HOME/RPG Game/Linux/Template/Storage/Player/Data/Player_Inv.json"
    
    case $1 in
        1)
            pl_name=$(jq -r '.Player["Name"]' "$path_pd")
            pl_class=$(jq -r '.Player["Class"]' "$path_pd")
            pl_lvl_cur=$(jq -r '.Player["Level Current"]' "$path_pd")
            pl_lvl_max=$(jq -r '.Player["Level Maximum"]' "$path_pd")
            pl_xp_cur=$(jq -r '.Player["XP Current"]' "$path_pd")
            pl_xp_max=$(jq -r '.Player["XP Maximum"]' "$path_pd")
            pl_hp_cur=$(jq -r '.Player["HP Current"]' "$path_pd")
            pl_hp_max=$(jq -r '.Player["HP Maximum"]' "$path_pd")
            pl_at_cur=$(jq -r '.Player["Attack Current"]' "$path_pd")
            pl_at_max=$(jq -r '.Player["Attack Maximum"]' "$path_pd")
            pl_def_cur=$(jq -r '.Player["Defense Current"]' "$path_pd")
            pl_def_max=$(jq -r '.Player["Defense Maximum"]' "$path_pd")
            pl_st_cur=$(jq -r '.Player["Strength Current"]' "$path_pd")
            pl_st_max=$(jq -r '.Player["Strength Maximum"]' "$path_pd")

            pl_l=$(jq -r '.Cash["Cash Lure"]' "$path_pd")
            pl_w=$(jq -r '.Cash["Cash Wart"]' "$path_pd")
            pl_c=$(jq -r '.Cash["Cash Cush"]' "$path_pd")
            pl_g=$(jq -r '.Cash["Cash Gilt"]' "$path_pd")

            pl_bc_c=$(jq -r '.Cash["Bank Credit Current"]' "$path_pd")
            pl_bp_pm=$(jq -r '.Cash["Bank Plus per Month"]' "$path_pd")
            pl_bm_pm=$(jq -r '.Cash["Bank Minus per Month"]' "$path_pd")
            pl_op_pm=$(jq -r '.Cash["Other Plus per Month"]' "$path_pd")
            pl_om_pm=$(jq -r '.Cash["Other Minus per Month"]' "$path_pd")
            pl_md=$(jq -r '.Cash["Money Dept"]' "$path_pd")

            pl_cash_1=$((pl_l + pl_w + pl_c + pl_g))
            pl_cash_2=$((pl_bc_c + pl_bp_pm + pl_op_pm))
            pl_cash_3=$((pl_bm_pm + pl_om_pm + pl_md))
            pl_cash=$((pl_cash_1 + pl_cash_2 - pl_cash_3))

            pl_h_m=$(jq -r '.Player_Armor["Head Maximum HP"]' "$path_pa")
            pl_c_m=$(jq -r '.Player_Armor["Chest Maximum HP"]' "$path_pa")
            pl_l_m=$(jq -r '.Player_Armor["Legs Maximum HP"]' "$path_pa")
            pl_f_m=$(jq -r '.Player_Armor["Feet Maximum HP"]' "$path_pa")
            pl_a_m=$(jq -r '.Player_Armor["Arms Maximum HP"]' "$path_pa")
            pl_h_m=$(jq -r '.Player_Armor["Hands Maximum HP"]' "$path_pa")

            pl_h_c=$(jq -r '.Player_Armor["Head Current HP"]' "$path_pa")
            pl_c_c=$(jq -r '.Player_Armor["Chest Current HP"]' "$path_pa")
            pl_l_c=$(jq -r '.Player_Armor["Legs Current HP"]' "$path_pa")
            pl_f_c=$(jq -r '.Player_Armor["Feet Current HP"]' "$path_pa")
            pl_a_c=$(jq -r '.Player_Armor["Arms Current HP"]' "$path_pa")
            pl_h_c=$(jq -r '.Player_Armor["Hands Current HP"]' "$path_pa")

            pl_armor_max=$(expr $pl_h_m + $pl_c_m + $pl_l_m + $pl_f_m + $pl_a_m + $pl_h_m)
            pl_armor_cur=$(expr $pl_h_c + $pl_c_c + $pl_l_c + $pl_f_c + $pl_a_c + $pl_h_c)

            pl_wep=$(jq -r '.Player_Equip["Weapon Name"]' "$path_pa")
            pl_wep_am_cur=$(jq -r '.Player_Equip["Equip Ammo Current"]' "$path_pa")
            pl_wep_am_st_cur=$(jq -r '.Player_Equip["Equip Ammo Stack Current"]' "$path_pa")

            pl_tl=$(jq -r '.Player_Equip["Tool Name"]' "$path_pa")
            pl_tl_am_cur=$(jq -r '.Player_Equip["Tool Ammo Current"]' "$path_pa")
            pl_tl_am_st_cur=$(jq -r '.Player_Equip["Tool Ammo Stack Current"]' "$path_pa")
            pl_tl_fl_cur=$(jq -r '.Player_Equip["Tool Fuel Current"]' "$path_pa")

            pl_sk_01=$(jq -r '.Skills["Skill 01"]' "$path_pa")
            pl_sk_02=$(jq -r '.Skills["Skill 02"]' "$path_pa")
            pl_sk_03=$(jq -r '.Skills["Skill 03"]' "$path_pa")
            pl_sk_04=$(jq -r '.Skills["Skill 04"]' "$path_pa")
            pl_sk_05=$(jq -r '.Skills["Skill 05"]' "$path_pa")
            pl_sk_06=$(jq -r '.Skills["Skill 06"]' "$path_pa")
            pl_sk_07=$(jq -r '.Skills["Skill 07"]' "$path_pa")
            pl_sk_08=$(jq -r '.Skills["Skill 08"]' "$path_pa")
            pl_sk_09=$(jq -r '.Skills["Skill 09"]' "$path_pa")
            pl_sk_10=$(jq -r '.Skills["Skill 10"]' "$path_pa")

            #pl_sk=["$pl_sk_01", "$pl_sk_02", "$pl_sk_03", "$pl_sk_04", "$pl_sk_05", "$pl_sk_06", "$pl_sk_07", "$pl_sk_08", "$pl_sk_09", "$pl_sk_10"]

            counter_set=0
            counter_true=5

            #for s in "$pl_sk"
            #do
            #    if [ "$s" != "null" ]; then
            #        counter_true=$(expr $counter_true + 1)
            #    else
            #        counter_true=$(expr $counter_true - 1)
            #    fi
            #done

            #if [ "$counte_true" -le "$counter_set" ]; then
            #    $counter_true=0
            #fi

            dialog --title "Overview" --msgbox "
                Name:     $pl_name / Class: $pl_class
                Level:    $pl_lvl_cur / $pl_lvl_max
                XP:       $pl_xp_cur / $pl_xp_mx
                HP:       $pl_hp_cur / $pl_hp_max
                Attack:   $pl_at_cur / $pl_at_max
                Defense:  $pl_def_cur / $pl_def_max
                Strength: $pl_st_cur / $pl_st_max
                Cash:     $pl_cash
                Armor HP: $pl_armor_cur / $pl_armor_max
                Weapon:   $pl_wep / $pl_wep_am_cur / $pl_wep_am_st_cur
                Tool:     $pl_tl / $pl_tl_am_cur / $pl_tl_am_st_cur / $pl_tl_fl_cur
                Skills:   $counter_true" 18 40
        ;;

    2) 
        head_name=$(jq -r '.Player_Armor["Head Name"]' "$path_pa")
        head_cur_hp=$(jq -r '.Player_Armor["Head Current HP"]' "$path_pa")
        head_max_hp=$(jq -r '.Player_Armor["Head Maximum HP"]' "$path_pa")

        chest_name=$(jq -r '.Player_Armor["Chest Name"]' "$path_pa")
        chest_cur_hp=$(jq -r '.Player_Armor["Chest Current HP"]' "$path_pa")
        chest_max_hp=$(jq -r '.Player_Armor["Chest Maximum HP"]' "$path_pa")

        legs_name=$(jq -r '.Player_Armor["Legs Name"]' "$path_pa")
        legs_cur_hp=$(jq -r '.Player_Armor["Legs Current HP"]' "$path_pa")
        legs_max_hp=$(jq -r '.Player_Armor["Legs Maximum HP"]' "$path_pa")

        feet_name=$(jq -r '.Player_Armor["Feet Name"]' "$path_pa")
        feet_cur_hp=$(jq -r '.Player_Armor["Feet Current HP"]' "$path_pa")
        feet_max_hp=$(jq -r '.Player_Armor["Feet Maximum HP"]' "$path_pa")

        arms_name=$(jq -r '.Player_Armor["Arms Name"]' "$path_pa")
        arms_cur_hp=$(jq -r '.Player_Armor["Arms Current HP"]' "$path_pa")
        arms_max_hp=$(jq -r '.Player_Armor["Arms Maximum HP"]' "$path_pa")

        hands_name=$(jq -r '.Player_Armor["Hands Name"]' "$path_pa")
        hands_cur_hp=$(jq -r '.Player_Armor["Hands Current HP"]' "$path_pa")
        hands_max_hp=$(jq -r '.Player_Armor["Hands Maximum HP"]' "$path_pa")
        
        dialog --title "Armor: HP" --msgbox "
            Head:  $head_name
            HP:    $head_cur_hp / $head_max_hp
            Chest: $chest_name
            HP:    $chest_cur_hp / $chest_max_hp
            Legs:  $legs_name
            HP:    $legs_cur_hp / $legs_max_hp
            Feet:  $feet_name
            HP:    $feet_cur_hp / $feet_max_hp
            Arms:  $arms_name
            HP:    $arms_cur_hp / $arms_max_hp
            Hands: $hands_name
            HP:    $hands_cur_hp / $hands_max_hp" 18 40
        ;;
    
    3)
        head_name=$(jq -r '.Player_Armor["Head Name"]' "$path_pa")
        head_cur_def=$(jq -r '.Player_Armor["Head Current Defense"]' "$path_pa")
        head_max_def=$(jq -r '.Player_Armor["Head Maximum Defense"]' "$path_pa")

        chest_name=$(jq -r '.Player_Armor["Chest Name"]' "$path_pa")
        chest_cur_def=$(jq -r '.Player_Armor["Chest Current Defense"]' "$path_pa")
        chest_max_def=$(jq -r '.Player_Armor["Chest Maximum Defense"]' "$path_pa")

        legs_name=$(jq -r '.Player_Armor["Legs Name"]' "$path_pa")
        legs_cur_def=$(jq -r '.Player_Armor["Legs Current Defense"]' "$path_pa")
        legs_max_def=$(jq -r '.Player_Armor["Legs Maximum Defense"]' "$path_pa")

        feet_name=$(jq -r '.Player_Armor["Feet Name"]' "$path_pa")
        feet_cur_def=$(jq -r '.Player_Armor["Feet Current Defense"]' "$path_pa")
        feet_max_def=$(jq -r '.Player_Armor["Feet Maximum Defense"]' "$path_pa")

        arms_name=$(jq -r '.Player_Armor["Arms Name"]' "$path_pa")
        arms_cur_def=$(jq -r '.Player_Armor["Arms Current Defense"]' "$path_pa")
        arms_max_def=$(jq -r '.Player_Armor["Arms Maximum Defense"]' "$path_pa")

        hands_name=$(jq -r '.Player_Armor["Hands Name"]' "$path_pa")
        hands_cur_def=$(jq -r '.Player_Armor["Hands Current Defense"]' "$path_pa")
        hands_max_def=$(jq -r '.Player_Armor["Hands Maximum Defense"]' "$path_pa")

        dialog --title "Armor: Defense" --msgbox "
            Head:    $head_name
            Defense: $head_cur_def / $head_max_def
            Chest:   $chest_name
            Defense: $chest_cur_def / $chest_max_def
            Legs:    $legs_name
            Defense: $legs_cur_def / $legs_max_def
            Feet:    $feet_name
            Defense: $feet_cur_def / $feet_max_def
            Arms:    $arms_name
            Defense: $arms_cur_def / $arms_max_def
            Hands:   $hands_name
            Defense: $hands_cur_def / $hands_max_def" 18 40
        ;;

    4)
        w_name=$(jq -r '.Player_Equip["Equip Weapon Name"]' "$path_pa")
        w_ammo_cur=$(jq -r '.Player_Equip["Equip Ammo Current"]' "$path_pa")
        w_ammo_max=$(jq -r '.Player_Equip["Equip Ammo Maximum"]' "$path_pa")
        w_ammo_stack_cur=$(jq -r '.Player_Equip["Equip Ammo Stack Current"]' "$path_pa")
        w_ammo_stack_max=$(jq -r '.Player_Equip["Equip Ammo Stack Maximum"]' "$path_pa")
    
        t_name=$(jq -r '.Player_Equip["Tool Name"]' "$path_pa")
        t_ammo_cur=$(jq -r '.Player_Equip["Tool Ammo Current"]' "$path_pa")
        t_ammo_max=$(jq -r '.Player_Equip["Tool Ammo Maximum"]' "$path_pa")
        t_ammo_stack_cur=$(jq -r '.Player_Equip["Tool Ammo Stack Current"]' "$path_pa")
        t_ammo_stack_max=$(jq -r '.Player_Equip["Tool Ammo Stack Maximum"]' "$path_pa")
        t_fuel_cur=$(jq -r '.Player_Equip["Tool Fuel Current"]' "$path_pa")
        t_fuel_max=$(jq -r '.Player_Equip["Tool Fuel Current"]' "$path_pa")
    
        dialog --title "Weapons" --msgbox "
            ======Weapons======
            Weapon: $w_name
            Ammo:   $w_ammo_cur / $w_ammo_max
            Stack:  $w_ammo_stack_cur / $w_ammo_stack_max
            =======Equip=======
            Tool:   $t_name
            Ammo:   $t_ammo_cur / $t_ammo_max
            Stack:  $t_ammo_stack_cur / $t_ammo_stack_max
            Fuel:   $t_fuel_cur / $t_fuel_max" 18 40
        ;;

    5)
        c_l=$(jq -r '.Cash["Coin Lure"]' "$path_pd")
        c_w=$(jq -r '.Cash["Coin Wart"]' "$path_pd")
        c_c=$(jq -r '.Cash["Coin Cush"]' "$path_pd")
        c_g=$(jq -r '.Cash["Coin Gilt"]' "$path_pd")
    
        bc_c=$(jq -r '.Cash["Bank Credit Current"]' "$path_pd")
        bc_m=$(jq -r '.Cash["Bank Credit Maximum"]' "$path_pd")
        bp_pm=$(jq -r '.Cash["Bank Plus per Month"]' "$path_pd")
        bm_pm=$(jq -r '.Cash["Bank Minus per Month"]' "$path_pd")
        op_pm=$(jq -r '.Cash["Other Plus per Month"]' "$path_pd")
        om_pm=$(jq -r '.Cash["Other Minus per Month"]' "$path_pd")
        m_d=$(jq -r '.Cash["Money Dept"]' "$path_pd")
        
        dialog --title "Cash" --msgbox "
            Lure: $c_l
            Wart: $c_w
            Cush: $c_c
            Gilt: $c_g
            =======Bank========
            Bank Credit Current:    $bc_c
            Bank Credit Maximum:    $bc_m
            Bank: Plus per Month:   $bp_pm
            Bank: Minus per Month:  $bm_pm
            Other: Plus per Month:  $op_pm
            Other: Minus per Month: $om_pm
            Money Dept:             $m_d" 18 40
        ;;

    6)
        skill_level=$(jq -r '.Skills["Skill Level"]' "$path_pa")
        skill_xp=$(jq -r '.Skills["Skill XP"]' "$path_pa")
        skill_pas_cur=$(jq -r '.Skills["Skill Passive Current"]' "$path_pa")
        skill_pas_max=$(jq -r '.Skills["Skill Passive Maximum"]' "$path_pa")
        skill_akt_cur=$(jq -r '.Skills["Skill Aktive Current"]' "$path_pa")
        skill_akt_max=$(jq -r '.Skills["Skill Aktive Maximum"]' "$path_pa")

        skill_01=$(jq -r '.Skills["Skill 01"]' "$path_pa")
        skill_02=$(jq -r '.Skills["Skill 02"]' "$path_pa")
        skill_03=$(jq -r '.Skills["Skill 03"]' "$path_pa")
        skill_04=$(jq -r '.Skills["Skill 04"]' "$path_pa")
        skill_05=$(jq -r '.Skills["Skill 05"]' "$path_pa")

        skill_01_lvl=(jq -r '.Skills["Skill 01 Level"]' "$path_pa")
        skill_02_lvl=(jq -r '.Skills["Skill 02 Level"]' "$path_pa")
        skill_03_lvl=(jq -r '.Skills["Skill 03 Level"]' "$path_pa")
        skill_04_lvl=(jq -r '.Skills["Skill 04 Level"]' "$path_pa")
        skill_05_lvl=(jq -r '.Skills["Skill 05 Level"]' "$path_pa")

        dialog --title "Skills" --msgbox "
            Skill Level: $skill_level
            Skill XP:    $skill_xp
            Passive Skills Active: $skill_pas_cur / $skill_pas_max
            Active Skills Active:  $skill_akt_cur / $skill_akt_max
            
            Skill 1: $skill01 / Level: $skill_01_lvl
            Skill 2: $skill02 / Level: $skill_02_lvl
            Skill 3: $skill03 / Level: $skill_03_lvl
            Skill 4: $skill04 / Level: $skill_04_lvl
            Skill 5: $skill05 / Level: $skill_05_lvl" 18 40
        ;;

    esac
}

# Hauptmenü
while true; do
    choice=$(dialog --clear \
                    --title "Player Stats" \
                    --menu "Choos an option" \
                    15 50 6 \
                    1 "Overview" \
                    2 "Armor HP" \
                    3 "Armor Defense" \
                    4 "Weapons" \
                    5 "Cash" \
                    6 "Skills" \
                    2>&1 >/dev/tty)


    # Den rechten Teil aktualisieren
    show_info $choice
done

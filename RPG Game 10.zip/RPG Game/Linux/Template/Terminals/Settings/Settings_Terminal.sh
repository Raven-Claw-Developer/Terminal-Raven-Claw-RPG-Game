







# =================== Trolling ===================
# =================== Trolling ===================
# =================== Trolling ===================
# =================== Trolling ===================

troll_choice() {

    while true; do
        troll_toggle=$(dialog --clear \
                        --title "Toggle Trolling" \
                        --name " " \
                        15 50 6 \
                        1 "ON" \
                        2 "OFF" \
                        3 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $troll_toggle in
            1|2|3)
                break
                ;;
        esac
    done
}

# =================== Difficulty ===================
# =================== Difficulty ===================
# =================== Difficulty ===================
# =================== Difficulty ===================



dif_choice() {

    while true; do
        dif_opt=$(dialog --clear \
                        --title "Toggle Difficulty" \
                        --name " " \
                        15 50 6 \
                        1 "Peacfull" \
                        2 "Eazy" \
                        3 "Regular" \
                        4 "Hard" \
                        5 "Pro" \
                        6 "hehehe" \
                        7 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $dif_opt in
            1|2|3|4|5|6)
                break
                ;;
        esac
    done
}





# =================== Clock speed ===================
# =================== Clock speed ===================
# =================== Clock speed ===================
# =================== Clock speed ===================

clock_choice() {

    while true; do
        clock_opt=$(dialog --clear \
                        --title "Change Clock Speed" \
                        --name " " \
                        15 50 6 \
                        1 "0 || OFF" \
                        2 "x0.25" \
                        3 "x0.50" \
                        4 "x0.75" \
                        5 "x1.0 < Default" \
                        6 "x1.25" \
                        7 "x1.50" \
                        8 "x1.75" \
                        9 "x2.0" \
                        10  "x2.25" \
                        11 "x2.50" \
                        12 "x2.75" \
                        13 "x3" \
                        14 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $fx_vol in
            1|2|3|4|5|6|7|8|9|10|11|12|13|14)
                break
                ;;
        esac
    done
}




# =================== FX ===================
# =================== FX ===================
# =================== FX ===================
# =================== FX ===================


fx_volume() {

    while true; do
        fx_vol=$(dialog --clear \
                        --title "Volume: FX [%]" \
                        --name " " \
                        15 50 6 \
                        1 "5" \
                        2 "10" \
                        3 "15" \
                        4 "20" \
                        5 "25" \
                        6 "30" \
                        7 "35" \
                        8 "40" \
                        9 "45" \
                        10 "50" \
                        11 "55" \
                        12 "60" \
                        13 "65" \
                        14 "70" \
                        15 "75" \
                        16 "80" \
                        17 "85" \
                        18 "90" \
                        19 "95" \
                        20 "100" \
                        21 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $fx_vol in
            1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21)
                break
                ;;
        esac
    done
}


fx_toggle() {

    while true; do
        fx_toogle=$(dialog --clear \
                        --title "Toggle FX" \
                        --name " " \
                        15 50 6 \
                        1 "ON" \
                        2 "OFF" \
                        3 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $fx_toogle in
            1)
                cat "set_path" | jq '.Music.FX_State = true' > temp.json && mv tmp.json "$set_path"
                ;;
            2)
                cat "set_path" | jq '.Music.FX_State = false' > temp.json && mv tmp.json "$set_path"
                ;;
            3)
                break
                ;;
        esac
    done
}


fx_choice() {

    while true; do
        fx_opt=$(dialog --clear \
                        --title "Options: Fx" \
                        --name " " \
                        15 50 6 \
                        1 "Toogle" \
                        2 "Volume" \
                        3 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $fx_opt in
            1)
                fx_toogle
                ;;
            2) 
                fx_volume
                ;;
            3)
                break
                ;;
        esac
    done
}

# =================== Volume ===================
# =================== Volume ===================
# =================== Volume ===================
# =================== Volume ===================

music_volume() {
    local set_path=$1
    local vol=$2

    while true; do
        music_vol=$(dialog --clear \
                        --title "Volume: Music [%]" \
                        --name " " \
                        15 50 6 \
                        1 "5" \
                        2 "10" \
                        3 "15" \
                        4 "20" \
                        5 "25" \
                        6 "30" \
                        7 "35" \
                        8 "40" \
                        9 "45" \
                        10 "50" \
                        11 "55" \
                        12 "60" \
                        13 "65" \
                        14 "70" \
                        15 "75" \
                        16 "80" \
                        17 "85" \
                        18 "90" \
                        19 "95" \
                        20 "100" \
                        21 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $music_vol in
            1)
                cat "$set_path" | jq '.Music.Music_Vol = 5' > temp.json && mv tmp.json "$set_path"
                ;;
            2)
                cat "$set_path" | jq '.Music.Music_Vol = 10' > temp.json && mv tmp.json "$set_path"
                ;;
            3)
                cat "$set_path" | jq '.Music.Music_Vol = 15' > temp.json && mv tmp.json "$set_path"
                ;;
            4)
                cat "$set_path" | jq '.Music.Music_Vol = 20' > temp.json && mv tmp.json "$set_path"
                ;;
            5)
                cat "$set_path" | jq '.Music.Music_Vol = 25' > temp.json && mv tmp.json "$set_path"
                ;;
            6)
                cat "$set_path" | jq '.Music.Music_Vol = 30' > temp.json && mv tmp.json "$set_path"
                ;;
            7)
                cat "$set_path" | jq '.Music.Music_Vol = 35' > temp.json && mv tmp.json "$set_path"
                ;;
            8)
                cat "$set_path" | jq '.Music.Music_Vol = 40' > temp.json && mv tmp.json "$set_path"
                ;;
            9)
                cat "$set_path" | jq '.Music.Music_Vol = 45' > temp.json && mv tmp.json "$set_path"
                ;;
            10)
                cat "$set_path" | jq '.Music.Music_Vol = 50' > temp.json && mv tmp.json "$set_path"
                ;;
            11)
                cat "$set_path" | jq '.Music.Music_Vol = 55' > temp.json && mv tmp.json "$set_path"
                ;;
            12)
                cat "$set_path" | jq '.Music.Music_Vol = 60' > temp.json && mv tmp.json "$set_path"
                ;;
            13)
                cat "$set_path" | jq '.Music.Music_Vol = 65' > temp.json && mv tmp.json "$set_path"
                ;;
            14)
                cat "$set_path" | jq '.Music.Music_Vol = 70' > temp.json && mv tmp.json "$set_path"
                ;;
            15)
                cat "$set_path" | jq '.Music.Music_Vol = 75' > temp.json && mv tmp.json "$set_path"
                ;;
            16)
                cat "$set_path" | jq '.Music.Music_Vol = 80' > temp.json && mv tmp.json "$set_path"
                ;;
            17)
                cat "$set_path" | jq '.Music.Music_Vol = 85' > temp.json && mv tmp.json "$set_path"
                ;;
            18)
                cat "$set_path" | jq '.Music.Music_Vol = 90' > temp.json && mv tmp.json "$set_path"
                ;;
            19)
                cat "$set_path" | jq '.Music.Music_Vol = 95' > temp.json && mv tmp.json "$set_path"
                ;;
            20)
                cat "$set_path" | jq '.Music.Music_Vol = 100' > temp.json && mv tmp.json "$set_path"
                ;;
            21)
                break
                ;;
        esac
    done
}


music_toggle() {
    local set_path=$1
    local state=$2

    while true; do
        music_toogle=$(dialog --clear \
                        --title "Toggle Music" \
                        --name " " \
                        15 50 6 \
                        1 "ON" \
                        2 "OFF" \
                        3 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $music_toogle in
            1)
                cat "set_path" | jq '.Music.Music_State = true' > temp.json && mv tmp.json "$set_path"
                ;;
            2)
                cat "set_path" | jq '.Music.Music_State = false' > temp.json && mv tmp.json "$set_path"
                ;;
            3)
                break
                ;;
        esac
    done
}

music_choice() {
    local set_path=$1
    local music_state=$2
    local music_vol=$3

    while true; do
        music_opt=$(dialog --clear \
                        --title "Options: Music" \
                        --name " " \
                        15 50 6 \
                        1 "Toogle: $music_state" \
                        2 "Volume: $music_vol" \
                        3 "Cancel" \
                        2 >&1 >/dev/tty)
        
        case $music_opt in
            1)
                music_toogle "$set_path" "$music_state"
                ;;
            2) 
                music_volume "$set_path" "$music_vol"
                ;;
            3)
                break
                ;;
        esac
    done
}

# =================== Settings ===================
# =================== Settings ===================
# =================== Settings ===================
# =================== Settings ===================


while true; do

    path="$HOME/RPG Game/Linux/Template/Storage/Global/Settings/Settings.json"
    set_path="$path/Settings.json"

    music_state=$(jq -r '.Music["Music_State"]' "$set_path")
    fx_state=$(jq -r '.Music["FX_State"]' "$set_path")
    music_vol=$(jq -r '.Music["Music_Vol"]' "$set_path")
    fx_vol=$(jq -r '.Music["FX_Vol"]' "$set_path")
    clock_speed=$(jq -r '.Clock["Tick_Speed"]' "$set_path")
    diff_mode=$(jq -r '.Other["Difficulty"]' "$set_path")
    troll_state=$(jq -r '.Other["Trolling"]' "$set_path")
    
    options=$(dialog --clear \
                    --title "Settings" \
                    --name " " \
                    15 50 6 \
                    1 "Music: $music_state | $music_vol" \
                    2 "FX: $fx_state | $fx_vol" \
                    3 "Clock speed: $clock_speed" \
                    4 "Difficulty: $diff_mode" \
                    5 "Troll Mode: $troll_state" \
                    2>&1 >/def/tty)

    case $otions in
        1)
            music_choice "$set_path" "$music_state" "$music_vol"
            ;;
        2)
            fx_choice "$set_path" "$fx_state" "$fx_vol"
            ;;
        3)
            clock_choice "$set_path"
            ;;
        4)
            dif_choice "$set_path"
            ;;
        5)
            troll_choice "$set_path"
            ;;
    esac

done





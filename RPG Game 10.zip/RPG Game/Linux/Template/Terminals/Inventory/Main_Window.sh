#!/bin/bash

none() {
    dialog --title "Information" --msgbox "Diese Funktion ist noch nicht implementiert." 8 40
}



# ============ Crafting ===================








# =================== Other ===================
# =================== Other ===================
# =================== Other ===================
# =================== Other ===================

other_choice() {

    while true; do
        other_opt=$(dialog --clear \
                    --title "Other" \
                    --menu " " \
                    20 40 10 \
                    1 "Favourites" \
                    2 "Collectibles" \
                    3 "0" \
                    4 "0" \
                    5 "0"  \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $other_opt in
            1|2|3|4|5|6) 
                break
                ;;
        esac
    done
}



# =================== Defense ===================
# =================== Defense ===================
# =================== Defense ===================
# =================== Defense ===================

def_ammo_choice() {

    while true; do
        def_am_opt=$(dialog --clear \
                    --title "Defense: Ammo" \
                    --menu " " \
                    20 40 10 \
                    1 "Ammo 1" \
                    2 "Ammo 2" \
                    3 "Ammo 3" \
                    4 "Ammo 4" \
                    5 "Ammo 5"  \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $def_am_opt in
            1|2|3|4|5|6) 
                break
                ;;
        esac
    done
}

def_pas_choice() {

    while true; do
        def_pas_opt=$(dialog --clear \
                    --title "Defense: Passive" \
                    --menu " " \
                    20 40 10 \
                    1 "Walls: Small" \
                    2 "Walls: Big" \
                    3 "Gates: Small" \
                    4 "Gate: Big" \
                    5 "Traps" \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $def_pas_opt in
            1|2|3|4|5|6) 
                break
                ;;
        esac
    done
}

def_act_choice_choice() {

    while true; do
        def_act_opt=$(dialog --clear \
                    --title "Defense: Active" \
                    --menu " " \
                    20 40 10 \
                    1 "Turret Stations" \
                    2 "Radar Stations" \
                    3 "Traps" \
                    4 "Back" \
                    2>&1 >/dev/tty)

        case $def_act_opt in
            1|2|3|4) 
                break
                ;;
        esac
    done
}

defense_choice_choice() {

    while true; do
        def_opt=$(dialog --clear \
                    --title "Defense" \
                    --menu " " \
                    20 40 10 \
                    1 "Active" \
                    2 "Passive" \
                    3 "Ammo" \
                    4 "Sensors" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $def_opt in
            1)
                def_act_choice
                ;;
            2)
                def_pas_choice
                ;;
            3)
                def_ammo_choice
                ;;
            4)
                def_sensors_choice
                ;;
            5) 
                break
                ;;
        esac
    done
}


# =================== Transport ===================
# =================== Transport ===================
# =================== Transport ===================
# =================== Transport ===================

trans_objects_choice() {

    while true; do
        trans_obj_opt=$(dialog --clear \
                    --title "Transport: Objects" \
                    --menu " " \
                    20 40 10 \
                    1 "Air" \
                    2 "Water" \
                    3 "Land" \
                    4 "Teleport" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $trans_obj_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

trans_main_choice() {

    while true; do
        trans_ma_opt=$(dialog --clear \
                    --title "Transport: Main" \
                    --menu " " \
                    20 40 10 \
                    1 "Main 1" \
                    2 "Main 2" \
                    3 "Main 3" \
                    4 "Main 4" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $trans_ma_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

trans_base_choice() {

    while true; do
        trans_ba_opt=$(dialog --clear \
                    --title "Transport: Base" \
                    --menu " " \
                    20 40 10 \
                    1 "Base 1" \
                    2 "Base 2" \
                    3 "Base 3" \
                    4 "Base 4" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $trans_ba_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

transport_choice() {

    while true; do
        trans_opt=$(dialog --clear \
                    --title "Transport" \
                    --menu " " \
                    20 40 10 \
                    1 "Base" \
                    2 "Modules" \
                    3 "Objects" \
                    4 "Back" \
                    2>&1 >/dev/tty)

        case $trans_opt in
            1)
                trans_base_choice
                ;;
            2)
                trans_modules_choice
                ;;
            3)
                trans_objects_choice
                ;;
            4) 
                break
                ;;
        esac
    done
}

# =================== Electric ===================
# =================== Electric ===================
# =================== Electric ===================
# =================== Electric ===================


elec_wire_choice() {

    while true; do
        elec_wire_opt=$(dialog --clear \
                    --title "Electric: Wireless" \
                    --menu " " \
                    20 40 10 \
                    1 "Transmitter" \
                    2 "Receiver" \
                    3 "Repeater" \
                    4 "Switch" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $elec_wire_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

elec_comp_choice() {

    while true; do
        elec_comp_opt=$(dialog --clear \
                    --title "Electric: Components" \
                    --menu " " \
                    20 40 10 \
                    1 "Active" \
                    2 "Passive" \
                    3 "Sensors" \
                    4 "Controller" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $elec_comp_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

elec_main_choice() {

    while true; do
        elec_main_opt=$(dialog --clear \
                    --title "Electric: Main" \
                    --menu " " \
                    20 40 10 \
                    1 "Main 1" \
                    2 "Main 2" \
                    3 "Main 3" \
                    4 "Main 4" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $elec_main_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

elec_base_choice() {

    while true; do
        elec_base_opt=$(dialog --clear \
                    --title "Electric: Base" \
                    --menu " " \
                    20 40 10 \
                    1 "Base 1" \
                    2 "Base 2" \
                    3 "Base 3" \
                    4 "Base 4" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $elec_base_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}

electric_choice() {

    while true; do
        elec_opt=$(dialog --clear \
                    --title "Electric" \
                    --menu " " \
                    20 40 10 \
                    1 "Base" \
                    2 "Main" \
                    3 "Components" \
                    4 "Wireless" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $elec_opt in
            1)
                elec_base_choice
                ;;
            2)
                elec_main_choice
                ;;
            3)
                elec_comp_choice
                ;;
            4)
                elec_wire_choice
                ;;
            5) 
                break
                ;;
        esac
    done
}


# =================== Food ===================
# =================== Food ===================
# =================== Food ===================
# =================== Food ===================


vegis_choice() {

    while true; do
        vegis_opt=$(dialog --clear \
                    --title "Food: Vegi" \
                    --menu " " \
                    20 40 10 \
                    1 "Fruit" \
                    2 "Vegi" \
                    3 "Back" \
                    2>&1 >/dev/tty)

        case $vegis_opt in
            1|2|3) 
                break
                ;;
        esac
    done
}

meats_choice() {

    while true; do
        food_opt=$(dialog --clear \
                    --title "Food: Meat" \
                    --menu " " \
                    20 40 10 \
                    1 "Raw Meat" \
                    2 "Processed Meat" \
                    3 "Organs" \
                    4 "Bones" \
                    5 "Skin" \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $food_opt in
            1|2|3|4|5|6) 
                break
                ;;
        esac
    done
}

foods_choice() {

    while true; do
        food_opt=$(dialog --clear \
                    --title "Food" \
                    --menu " " \
                    20 40 10 \
                    1 "Meat" \
                    2 "Vegi" \
                    3 "Salty Stuff" \
                    4 "Sweet Stuff" \
                    5 "Back" \
                    2>&1 >/dev/tty)

        case $food_opt in
            1)
                meats_choice
                ;;    
            2)
                vegis_choice
                ;;
            3|4) 
                break
                ;;
        esac
    done
}


# =================== Building ===================
# =================== Building ===================
# =================== Building ===================
# =================== Building ===================


building_choice() {

    while true; do
        build_opt=$(dialog --clear \
                    --title "Building" \
                    --menu " " \
                    20 40 10 \
                    1 "Base 1" \
                    2 "Base 2" \
                    3 "Base 3" \
                    4 "Main 1" \
                    5 "Main 2" \
                    6 "Main 3" \
                    7 "Deco 1" \
                    8 "Deco 2" \
                    9 "Deco 3" \
                    10 "Back" \
                    2>&1 >/dev/tty)

        case $build_opt in
            1|2|3|4|5|6|7|8|9|10) 
                break
                ;;
        esac
    done
}



# =================== Equipment ===================
# =================== Equipment ===================
# =================== Equipment ===================
# =================== Equipment ===================


kits_choice() {

    while true; do
        kits_opt=$(dialog --clear \
                    --title "Armor: Kits" \
                    --menu " " \
                    20 40 10 \
                    1 "Kit 1" \
                    2 "Kit 2" \
                    3 "Kit 3" \
                    4 "Kit 4" \
                    5 "Kit 5" \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $kits_opt in
            1|2|3|4|5|6) 
                break
                ;;
        esac
    done
}

addons_choice() {
    while true; do
        addons_opt=$(dialog --clear \
                    --title "Armor: Addons" \
                    --menu " " \
                    20 40 10 \
                    1 "Armor 1" \
                    2 "Armor 2" \
                    3 "Armor 3" \
                    4 "Fuel 1" \
                    5 "Fuel 2" \
                    6 "Electric 1" \
                    7 "Electric 2" \
                    8 "Electric 3" \
                    9 "Back" \
                    2>&1 >/dev/tty)

        case $addons_opt in
            1|2|3|4|5|6|7|8|9|10) 
                break
                ;;
        esac
    done
}


tools_choice() {
    while true; do
        tools_opt=$(dialog --clear \
                    --title "Armor: Tools" \
                    --menu " " \
                    20 40 10 \
                    1 "Wood" \
                    2 "Stone" \
                    3 "Fluids" \
                    4 "Gas" \
                    5 "Fire" \
                    6 "Ores" \
                    7 "Mobs" \
                    8 "Electric" \
                    9 "Back" \
                    2>&1 >/dev/tty)

        case $tools_opt in
            1|2|3|4|5|6|7) 
                break
                ;;
        esac
    done
}

weapons_choice() {
    while true; do
        weapon_opt=$(dialog --clear \
                    --title "Armor: Weapons" \
                    --menu " " \
                    20 40 10 \
                    1 "Short Range" \
                    2 "Mid Range" \
                    3 "Long Range" \
                    4 "Signle Hand" \
                    5 "Double Hand" \
                    2>&1 >/dev/tty)

        case $weapon_opt in
            1|2|3|4|5) 
                break
                ;;
        esac
    done
}


armor_choice() {
    while true; do
        armor_opt=$(dialog --clear \
                    --title "Armor" \
                    --menu " " \
                    20 40 10 \
                    1 "Head" \
                    2 "Chest" \
                    3 "Legs" \
                    4 "Feet" \
                    5 "Arms" \
                    6 "Hands" \
                    7 "Back" \
                    2>&1 >/dev/tty)

        case $armor_opt in
            1|2|3|4|5|6|7) 
                break
                ;;
        esac
    done
}

equip_choice() {
    while true; do
        equip_opt=$(dialog --clear \
                    --title "Inv: Equip" \
                    --menu " " \
                    20 40 10 \
                    1 "Armor" \
                    2 "Weapons" \
                    3 "Tools" \
                    4 "Addons" \
                    5 "Kits" \
                    6 "Back" \
                    2>&1 >/dev/tty)

        case $equip_opt in
            1) 
                armor_choice
                ;;
            2)
                weapons_choice
                ;;
            
            3)
                tools_choice
                ;;
            
            4)
                addons_choice
                ;;

            5|6) 
                break
                ;;
        esac
    done
}

# ==================== Inventory ====================
# ==================== Inventory ====================
# ==================== Inventory ====================
# ==================== Inventory ====================

inv_choice() {
    while true; do
        inv_opt=$(dialog --clear \
                    --title "Inventory" \
                    --menu " " \
                    20 40 10 \
                    1 "Equipment" \
                    2 "Building" \
                    3 "Food" \
                    4 "Electric" \
                    5 "Transport" \
                    6 "Defense" \
                    7 "Other" \
                    8 "Back" \
                    2>&1 >/dev/tty)

        case $inv_opt in
            1) 
                equip_choice
                ;;
            2)
                building_choice
                ;;
            3)
                foods_choice
                ;;
            4)
                electric_choice
                ;;
            5)
                transport_choice
                ;;
            6)
                defense_choice
                ;;
            7) 
                other_choice
                ;;
            8)
                break
                ;;
        esac
    done
}





while true; do
    options_main=$(dialog --clear \
                    --title "Main Menu" \
                    --menu " " \
                    20 40 10 \
                    1 "Inventory" \
                    2 "Crafting" \
                    3 "Brewing" \
                    4 "Portabel" \
                    5 "Skills" \
                    6 "Other" \
                    7 "Search" \
                    2>&1 >/dev/tty)

    case $options_main in
        1) 
            inv_choice
            ;;
        2|3|4|5|6) 
            none
            ;;
        7)
            search_loop
            ;;
    esac
done

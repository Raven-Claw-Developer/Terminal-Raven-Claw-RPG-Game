#!/bin/bash

# Define the relative path to the Player_Info.ksh script
Inv="$HOME/RPG Game/Linux/Template/Terminals/Inventory/Main_Window.sh"
chmod +x "$Inv"

# Run the command with konsole
konsole --new-tab --hold -p tabtitle="Inventory" -e bash -c "bash \"$Inv\"" &


